import pandas as pd

# Load CSV
df = pd.read_csv("data/all_media_data.csv")

# Keep only movie or tv rows
df = df[df['type'].isin(['movie', 'tv'])]

# Convert scores to numeric, coercing errors to NaN
df['metascore'] = pd.to_numeric(df['metascore'], errors='coerce')
df['user_score'] = pd.to_numeric(df['user_score'], errors='coerce')

# Split into movies and tv
movies = df[df['type'] == 'movie']
tv = df[df['type'] == 'tv']

# Filter rows with at least one score
movies_scores = movies.dropna(subset=['metascore', 'user_score'], how='all')
tv_scores = tv.dropna(subset=['metascore', 'user_score'], how='all')

# Platforms
movie_platforms = movies['platform'].dropna()
tv_platforms = tv['platform'].dropna()
print(f"Total movies: {len(movies)}, with scores: {len(movies_scores)}")
print(f"Total TV shows: {len(tv)}, with scores: {len(tv_scores)}")
print(f"Movies with platform info: {len(movie_platforms)}")
print(f"TV shows with platform info: {len(tv_platforms)}")
