# scrape_metacritic_universal.py
import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

CHROMEDRIVER_PATH = "/opt/homebrew/bin/chromedriver"
INPUT_CSV = "data/metacritic_links.csv"
OUTPUT_CSV = "data/metacritic_scraped.csv"

# ==========================
# Selenium setup
# ==========================
def get_driver():
    options = Options()
    options.add_argument("--headless")  # run in background
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--window-size=1920,1080")
    options.add_argument(
        "user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
    )
    service = Service(CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=options)
    return driver

# ==========================
# Detect page type
# ==========================
def detect_page_type(driver):
    url = driver.current_url
    if "/movie/" in url:
        return "movie"
    elif "/game/" in url:
        return "game"
    elif "/tv/" in url:
        return "tv"
    elif "/music/" in url:
        return "music"
    return "unknown"

# ==========================
# Scrapers per type
# ==========================
def scrape_movie(driver):
    try:
        title = driver.find_element(By.CSS_SELECTOR, "div.product_title a").text.strip()
    except:
        title = ""

    try:
        metascore = driver.find_element(By.CSS_SELECTOR, "a.metascore_anchor div").text.strip()
    except:
        metascore = ""

    try:
        user_score = driver.find_element(By.CSS_SELECTOR, "div.user").text.strip()
    except:
        user_score = ""

    try:
        desc = driver.find_element(By.CSS_SELECTOR, "div.summary_deck span").text.strip()
    except:
        desc = ""

    try:
        genres = driver.find_element(By.CSS_SELECTOR, "li.product_genre span.data").text.strip()
    except:
        genres = ""

    return {
        "type": "movie",
        "title": title,
        "metascore": metascore,
        "user_score": user_score,
        "genres": genres,
        "description": desc,
    }

def scrape_game(driver):
    try:
        title = driver.find_element(By.CSS_SELECTOR, "div.product_title a").text.strip()
    except:
        title = ""

    try:
        metascore = driver.find_element(By.CSS_SELECTOR, "a.metascore_anchor div").text.strip()
    except:
        metascore = ""

    try:
        user_score = driver.find_element(By.CSS_SELECTOR, "div.metascore_w.user").text.strip()
    except:
        user_score = ""

    try:
        platform = driver.find_element(By.CSS_SELECTOR, "span.platform").text.strip()
    except:
        platform = ""

    return {
        "type": "game",
        "title": title,
        "metascore": metascore,
        "user_score": user_score,
        "platform": platform,
    }

def scrape_tv(driver):
    try:
        title = driver.find_element(By.CSS_SELECTOR, "div.product_title a").text.strip()
    except:
        title = ""

    try:
        metascore = driver.find_element(By.CSS_SELECTOR, "a.metascore_anchor div").text.strip()
    except:
        metascore = ""

    try:
        user_score = driver.find_element(By.CSS_SELECTOR, "div.user").text.strip()
    except:
        user_score = ""

    return {
        "type": "tv",
        "title": title,
        "metascore": metascore,
        "user_score": user_score,
    }

def scrape_music(driver):
    try:
        title = driver.find_element(By.CSS_SELECTOR, "div.product_title a").text.strip()
    except:
        title = ""

    try:
        metascore = driver.find_element(By.CSS_SELECTOR, "a.metascore_anchor div").text.strip()
    except:
        metascore = ""

    try:
        user_score = driver.find_element(By.CSS_SELECTOR, "div.user").text.strip()
    except:
        user_score = ""

    return {
        "type": "music",
        "title": title,
        "metascore": metascore,
        "user_score": user_score,
    }

# ==========================
# Universal scrape function
# ==========================
def scrape_page(driver, url):
    driver.get(url)
    time.sleep(2)

    page_type = detect_page_type(driver)

    if page_type == "movie":
        data = scrape_movie(driver)
    elif page_type == "game":
        data = scrape_game(driver)
    elif page_type == "tv":
        data = scrape_tv(driver)
    elif page_type == "music":
        data = scrape_music(driver)
    else:
        data = {"type": "unknown"}

    data["link"] = url
    return data

# ==========================
# Main loop
# ==========================
if __name__ == "__main__":
    df_links = pd.read_csv(INPUT_CSV)
    urls = df_links["link"].dropna().tolist()

    driver = get_driver()
    results = []

    for url in urls:
        print("Scraping:", url)
        try:
            result = scrape_page(driver, url)
            results.append(result)
        except Exception as e:
            print(f"❌ Failed to scrape {url}: {e}")

    driver.quit()

    df_out = pd.DataFrame(results)
    df_out.to_csv(OUTPUT_CSV, index=False, encoding="utf-8")
    print(f"✅ Done! Scraped {len(results)} pages → {OUTPUT_CSV}")
