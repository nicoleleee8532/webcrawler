import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# --------------------------
# 1️⃣ Load & Clean Data
# --------------------------
df = pd.read_csv("data/all_media_data.csv")

# Keep only relevant types
df = df[df['type'].isin(['movie', 'tv'])]

# Convert scores to numeric, ignore errors
df['metascore'] = pd.to_numeric(df['metascore'], errors='coerce')
df['user_score'] = pd.to_numeric(df['user_score'], errors='coerce')

# --------------------------
# 2️⃣ Separate Movies & TV
# --------------------------
movies = df[df['type'] == 'movie']
tv = df[df['type'] == 'tv']

# Filter rows with at least one score
movies_scores = movies.dropna(subset=['metascore', 'user_score'], how='all')
tv_scores = tv.dropna(subset=['metascore', 'user_score'], how='all')

# Platforms
movie_platforms = movies['platform'].dropna()
tv_platforms = tv['platform'].dropna()

# --------------------------
# 3️⃣ Summary Stats
# --------------------------
summary = {
    "Total Movies": len(movies),
    "Total TV Shows": len(tv),
    "Movies with Scores": len(movies_scores),
    "TV Shows with Scores": len(tv_scores),
    "Average Movie Metascore": round(movies_scores['metascore'].mean(), 2) if not movies_scores.empty else "N/A",
    "Average Movie User Score": round(movies_scores['user_score'].mean(), 2) if not movies_scores.empty else "N/A",
    "Average TV Metascore": round(tv_scores['metascore'].mean(), 2) if not tv_scores.empty else "N/A",
    "Average TV User Score": round(tv_scores['user_score'].mean(), 2) if not tv_scores.empty else "N/A",
    "Movies with Platform Info": len(movie_platforms),
    "TV Shows with Platform Info": len(tv_platforms)
}

# Save summary to a text file
with open("summary_stats.txt", "w") as f:
    for k, v in summary.items():
        f.write(f"{k}: {v}\n")

print("✅ Summary stats saved to summary_stats.txt")

# --------------------------
# 4️⃣ Visualizations
# --------------------------
sns.set(style="whitegrid")

# 4a. Count of Movies vs TV Shows
plt.figure(figsize=(6, 4))
sns.barplot(x=["Movies", "TV Shows"], y=[len(movies), len(tv)], palette="pastel")
plt.title("Total Movies vs TV Shows")
plt.ylabel("Count")
plt.savefig("count_movies_vs_tv.png")
plt.close()
print("✅ Count plot saved as count_movies_vs_tv.png")

# 4b. Top 5 Platforms for Movies
if not movie_platforms.empty:
    top_movie_platforms = movie_platforms.value_counts().head(5)
    top_movie_platforms.plot(kind='bar', color='skyblue', title='Top 5 Movie Platforms')
    plt.ylabel("Count")
    plt.savefig("top_movie_platforms.png")
    plt.close()
    print("✅ Top 5 movie platforms plot saved as top_movie_platforms.png")
else:
    print("No movie platform data to plot.")

# 4c. Top 5 Platforms for TV Shows
if not tv_platforms.empty:
    top_tv_platforms = tv_platforms.value_counts().head(5)
    top_tv_platforms.plot(kind='bar', color='salmon', title='Top 5 TV Platforms')
    plt.ylabel("Count")
    plt.savefig("top_tv_platforms.png")
    plt.close()
    print("✅ Top 5 TV platforms plot saved as top_tv_platforms.png")
else:
    print("No TV platform data to plot.")

# 4d. Average Scores Comparison (if score data exists)
plt.figure(figsize=(6, 4))
avg_scores = pd.DataFrame({
    "Metascore": [summary["Average Movie Metascore"], summary["Average TV Metascore"]],
    "User Score": [summary["Average Movie User Score"], summary["Average TV User Score"]]
}, index=["Movies", "TV Shows"])
avg_scores.plot(kind='bar')
plt.title("Average Scores Comparison")
plt.ylabel("Score")
plt.savefig("average_scores_comparison.png")
plt.close()
print("✅ Average scores plot saved as average_scores_comparison.png")
