import pandas as pd
import glob

# Step 1: Find all CSV files in a folder
csv_files = glob.glob("data/*.csv")  # replace data_folder with your folder path

# Step 2: Read and concatenate them
all_df = pd.concat([pd.read_csv(f) for f in csv_files], ignore_index=True)

# Step 3: Save into a single CSV
all_df.to_csv("all_media_data.csv", index=False)

print(f"✅ Combined {len(csv_files)} files into all_media_data.csv")
import pandas as pd
import glob

# Step 1: Find all CSV files in a folder
csv_files = glob.glob("data_folder/*.csv")  # replace data_folder with your folder path

# Step 2: Read and concatenate them
all_df = pd.concat([pd.read_csv(f) for f in csv_files], ignore_index=True)

# Step 3: Save into a single CSV
all_df.to_csv("all_media_data.csv", index=False)

print(f"✅ Combined {len(csv_files)} files into all_media_data.csv")
