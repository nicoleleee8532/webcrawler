# metacritic_scraper.py
import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# ==========================
# CONFIGURATION
# ==========================
CHROMEDRIVER_PATH = "/opt/homebrew/bin/chromedriver"  # Update to your chromedriver path
OUTPUT_CSV = "data/metacritic_in_theaters.csv"
METACRITIC_URL = "https://www.metacritic.com/browse/movies/score/metascore/theaters/date"

# ==========================
# SELENIUM SETUP
# ==========================
def get_driver():
    options = Options()
    # options.add_argument("--headless=new")  # Comment out for debugging / load content
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--window-size=1920,1080")
    options.add_argument(
        "user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
    )
    service = Service(CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=options)
    return driver

# ==========================
# SCRAPER
# ==========================
def scrape_metacritic_in_theaters():
    driver = get_driver()
    driver.get(METACRITIC_URL)
    print("🔍 Loading Metacritic In-Theaters page...")

    # Wait for the first movie card to load
    wait = WebDriverWait(driver, 10)
    wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "li.product")))

    # Scroll to bottom slowly to load all movies
    for i in range(3):
        driver.execute_script("window.scrollBy(0, document.body.scrollHeight / 3);")
        time.sleep(2)

    movies = []

    cards = driver.find_elements(By.CSS_SELECTOR, "li.product")
    for card in cards:
        try:
            # Title & Link
            title_elem = card.find_element(By.CSS_SELECTOR, "a.title")
            title = title_elem.text.strip()
            link = title_elem.get_attribute("href")

            # Genres
            metadata_spans = card.find_elements(By.CSS_SELECTOR, "div.clamp-metadata span")
            genres = metadata_spans[1].text.strip() if len(metadata_spans) > 1 else ""

            # Rating (Metascore)
            score_elem = card.find_element(By.CSS_SELECTOR, "a.metascore_anchor div")
            rating = score_elem.text.strip() if score_elem else "N/A"

            # Description (summary)
            desc_elem = card.find_element(By.CSS_SELECTOR, "div.summary")
            description = desc_elem.text.strip() if desc_elem else ""

            movies.append({
                "title": title,
                "genres": genres,
                "rating": rating,
                "description": description,
                "link": link
            })
        except Exception as e:
            print("Skipping a card due to error:", e)

    driver.quit()
    print(f"✅ Scraped {len(movies)} movies from Metacritic In Theaters")
    return movies

# ==========================
# SAVE TO CSV
# ==========================
def save_to_csv(movies, filename=OUTPUT_CSV):
    df = pd.DataFrame(movies)
    df.to_csv(filename, index=False, encoding="utf-8")
    print(f"✅ Saved data to {filename}")

# ==========================
# MAIN
# ==========================
if __name__ == "__main__":
    movies = scrape_metacritic_in_theaters()
    if movies:
        save_to_csv(movies)
