from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import shutil
import pandas as pd
import time

# ==========================
# CONFIGURATION
# ==========================
RT_IN_THEATERS_URL = "https://www.rottentomatoes.com/browse/in-theaters/"
OUTPUT_CSV = "rottentomatoes_in_theaters_full.csv"

# ==========================
# DRIVER SETUP
# ==========================
def get_driver():
    chromedriver_path = shutil.which("chromedriver")
    if not chromedriver_path:
        raise ValueError("ChromeDriver not found in PATH")

    options = Options()
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    service = Service(chromedriver_path)
    driver = webdriver.Chrome(service=service, options=options)
    return driver

# ==========================
# SCRAPER
# ==========================
def scrape_in_theaters():
    driver = get_driver()
    driver.get(RT_IN_THEATERS_URL)
    print("Loading Rotten Tomatoes In-Theaters page...")
    time.sleep(5)  # wait for JS to load

    movies = []

    # Movie cards (update selector if it changes)
    cards = driver.find_elements(By.CSS_SELECTOR, "a.js-tile-link")

    for card in cards:
        try:
            title = card.get_attribute("aria-label")  # movie title
            link = card.get_attribute("href")        # movie page

            # Optional: visit movie page to get genres and description
            driver.get(link)
            time.sleep(2)

            try:
                genres = [g.text for g in driver.find_elements(By.CSS_SELECTOR, "li.meta-row span:nth-child(2)")]
            except:
                genres = []

            try:
                description_tag = driver.find_element(By.CSS_SELECTOR, "div#movieSynopsis")
                description = description_tag.text.strip()
            except:
                description = ""

            try:
                rating_tag = driver.find_element(By.CSS_SELECTOR, "score-board")
                rating = rating_tag.get_attribute("tomatometerscore") or "N/A"
            except:
                rating = "N/A"

            movies.append({
                "title": title,
                "genres": ", ".join(genres),
                "rating": rating,
                "description": description,
                "link": link
            })
        except Exception as e:
            print("Skipping a card due to error:", e)
            continue

    driver.quit()
    print(f"✅ Scraped {len(movies)} movies from Rotten Tomatoes In-Theaters")
    return movies

# ==========================
# SAVE CSV
# ==========================
def save_to_csv(movies, filename=OUTPUT_CSV):
    df = pd.DataFrame(movies)
    df.to_csv(filename, index=False, encoding="utf-8")
    print(f"✅ Saved {len(movies)} movies to {filename}")

# ==========================
# MAIN
# ==========================
if __name__ == "__main__":
    movies = scrape_in_theaters()
    if movies:
        save_to_csv(movies)
