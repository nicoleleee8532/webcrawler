import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import shutil

# ==========================
# CONFIGURATION
# ==========================
OUTPUT_CSV = "data/netflix_trending.csv"
NETFLIX_URL = "https://www.netflix.com/browse/genre/839338"  # Example: trending movies

# ==========================
# SELENIUM SETUP
# ==========================
def get_driver():
    # Auto-find chromedriver in PATH
    chromedriver_path = shutil.which("chromedriver")
    if not chromedriver_path:
        raise ValueError(
            "ChromeDriver not found. Install it and make sure it's in your PATH."
        )

    options = Options()
    options.add_argument("--headless")  # Run in background
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--window-size=1920,1080")

    service = Service(chromedriver_path)
    driver = webdriver.Chrome(service=service, options=options)
    return driver

# ==========================
# NETFLIX SCRAPER
# ==========================
def scrape_netflix_trending():
    driver = get_driver()
    driver.get(NETFLIX_URL)
    print("Loading Netflix trending page...")
    time.sleep(5)  # Wait for content to load

    movies = []

    # Netflix movie cards - update selector if it changes
    cards = driver.find_elements(By.CSS_SELECTOR, "a.slider-refocus")

    for card in cards:
        try:
            title = card.get_attribute("aria-label")
            link = card.get_attribute("href")
            if not title:
                continue
            # Netflix does not expose genres or description without login
            movies.append({
                "title": title,
                "genres": "",
                "description": "",
                "rating": "",
                "link": link
            })
        except Exception as e:
            print("Skipping a card due to error:", e)

    driver.quit()
    print(f"✅ Scraped {len(movies)} movies from Netflix")
    return movies

# ==========================
# SAVE TO CSV
# ==========================
def save_to_csv(movies, filename=OUTPUT_CSV):
    df = pd.DataFrame(movies)
    df.to_csv(filename, index=False, encoding="utf-8")
    print(f"✅ Saved data to {filename}")

# ==========================
# MAIN
# ==========================
if __name__ == "__main__":
    movies = scrape_netflix_trending()
    if movies:
        save_to_csv(movies)
